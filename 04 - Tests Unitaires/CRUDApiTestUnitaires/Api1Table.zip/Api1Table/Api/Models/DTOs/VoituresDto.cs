﻿namespace Api.Models.DTOs
{
	public class VoituresDto
	{
		public int IdVoiture { get; set; }

		public string? Marque { get; set; }

		public string? Model { get; set; }

		public int? Km { get; set; }
	}
}
